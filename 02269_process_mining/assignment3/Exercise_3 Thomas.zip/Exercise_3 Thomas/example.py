{'case_772': [
    {'org:resource': 'admin-0', 'concept:name': 'record issue', 'cost': 10, 'time:timestamp': datetime.datetime(1970, 1, 1, 1, 0)}, 
    {'org:resource': 'inspector-5', 'concept:name': 'inspection', 'cost': 354, 'time:timestamp': datetime.datetime(1970, 1, 1, 2, 0)}, 
    {'org:resource': 'manager-1', 'concept:name': 'intervention authorization', 'cost': 116, 'time:timestamp': datetime.datetime(1970, 1, 1, 3, 0)}, 
    {'org:resource': 'admin-1', 'concept:name': 'no concession', 'cost': 50, 'time:timestamp': datetime.datetime(1970, 1, 1, 4, 0)}, 
    {'org:resource': 'admin-1', 'concept:name': 'issue completion', 'cost': 14, 'time:timestamp': datetime.datetime(1970, 1, 1, 5, 0)}
    ],
'case_834': [
    {'org:resource': 'admin-0', 'concept:name': 'record issue', 'cost': 10, 'time:timestamp': datetime.datetime(1970, 1, 1, 1, 0)}, 
    {'org:resource': 'inspector-4', 'concept:name': 'inspection', 'cost': 484, 'time:timestamp': datetime.datetime(1970, 1, 1, 2, 0)}, 
    {'org:resource': 'manager-1', 'concept:name': 'action not required', 'cost': 14, 'time:timestamp': datetime.datetime(1970, 1, 1, 3, 0)}, 
    {'org:resource': 'admin-1', 'concept:name': 'issue completion', 'cost': 14, 'time:timestamp': datetime.datetime(1970, 1, 1, 4, 0)}
    ]
}
